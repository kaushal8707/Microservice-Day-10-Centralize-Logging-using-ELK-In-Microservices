package com.selfdeveloped.spring.pos.api.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.selfdeveloped.spring.pos.api.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Integer>{

	Payment findByOrderId(int orderId);
 
}
